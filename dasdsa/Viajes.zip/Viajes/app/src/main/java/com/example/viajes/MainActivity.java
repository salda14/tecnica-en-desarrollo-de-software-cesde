package com.example.viajes;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    TextView jtvsubtotal,jtviva,jtvtotal,jtvvehiculo,jtvciudad;
    RadioButton jrbcartagena,jrbleticia,jrbpuntacana;
    CheckBox jcbvehiculo;
    EditText jetcantidad;
    DecimalFormat formato=new DecimalFormat("#.##");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Ocultar la barra de titulo por defecto
        getSupportActionBar().hide();
        //Asociar los objetos Java con los objetos Xml
        jtvsubtotal=findViewById(R.id.tvsubtotal);
        jtviva=findViewById(R.id.tviva);
        jtvtotal=findViewById(R.id.tvtotal);
        jtvvehiculo=findViewById(R.id.tvvehiculo);
        jtvciudad=findViewById(R.id.tvciudad);
        jrbcartagena=findViewById(R.id.rbcartagena);
        jrbleticia=findViewById(R.id.rbleticia);
        jrbpuntacana=findViewById(R.id.rbpuntacana);
        jcbvehiculo=findViewById(R.id.cbautomovil);
        jetcantidad=findViewById(R.id.etcantidad);
    }//fin Oncreate

    public void Calcular(View view){
        String cantidad;
        cantidad=jetcantidad.getText().toString();
        if (cantidad.isEmpty()){
            Toast.makeText(this, "La cantidad de personas es requerida", Toast.LENGTH_SHORT).show();
            jetcantidad.requestFocus();
        }else{
            int cantidad_personas,valor_viaje,valor_vehiculo;
            float subtotal,iva,total;
            //Conversion de String a entero
            cantidad_personas=Integer.parseInt(cantidad);
            //Valor que depende de la ciudad a seleccionar
            if (jrbcartagena.isChecked()){
                jtvciudad.setText("1400000");
                valor_viaje=1400000;
            }else{
                if (jrbleticia.isChecked()){
                    jtvciudad.setText("2000000");
                    valor_viaje=2000000;
                }else{
                    jtvciudad.setText("3200000");
                    valor_viaje=3200000;
                }
            }//fin lo de ciudad
            // Operacion del vehiculo
            if (jcbvehiculo.isChecked()){
                jtvvehiculo.setText("300000");
                valor_vehiculo=300000;
            }else{
                jtvvehiculo.setText("0");
                valor_vehiculo=0;
            } //fin operacion vehiculo
            //Calcular valores finales subtotal,iva,total
            subtotal=cantidad_personas * valor_viaje + valor_vehiculo;
            iva=(subtotal * 19)/100;
            total=subtotal + iva;
            //Imprimir resultados
            jtvsubtotal.setText(formato.format(subtotal));
            jtviva.setText(formato.format(iva));
            jtvtotal.setText(formato.format(total));
        }
    }//Fin calcular

    public void Limpiar(View view) {
        jrbcartagena.setChecked(true);
        jtvciudad.setText("1400000");
        jcbvehiculo.setChecked(false);
        jtvvehiculo.setText("0");
        jetcantidad.setText("");
        jtvsubtotal.setText("");
        jtviva.setText("");
        jtvtotal.setText("");
        jetcantidad.requestFocus();
    }
}